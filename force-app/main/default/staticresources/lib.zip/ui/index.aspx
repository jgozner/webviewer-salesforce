<!DOCTYPE html>
<html moznomarginboxes mozdisallowselectionprint>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex">
  <link rel="icon" href="assets/apryse.svg">
  <title>WebViewer UI</title>
</head>

<body>
  <div id="app"></div>
  <div id="line-connector-wrapper">
    <div id="line-connector-root"></div>
  </div>
  <div id="outline-edit-popup-portal"></div>
  <script src="../core/webviewer-core.min.js"></script>
  <script src="webviewer-ui.min.js"></script>
</body>

</html>